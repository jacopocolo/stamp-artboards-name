//Labels settings
//Change these 👇 to tweak the aspect of the label
//then save and run the plugin again

var labelColor = "#ffff00";
var textColor = "#000000";
var textSize = 12;
var padding = 10;
var fontFamily = 'Helvetica';